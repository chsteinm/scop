var searchData=
[
  ['exponential_20functions_4407',['Exponential functions',['../a00813.html',1,'']]],
  ['experimental_20extensions_4408',['Experimental extensions',['../a00905.html',1,'']]]
];
