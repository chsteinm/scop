var searchData=
[
  ['matrix_20functions_4581',['Matrix functions',['../a00993.html',1,'']]],
  ['matrix_20types_4582',['Matrix types',['../a00901.html',1,'']]],
  ['matrix_20types_20with_20precision_20qualifiers_4583',['Matrix types with precision qualifiers',['../a00902.html',1,'']]]
];
